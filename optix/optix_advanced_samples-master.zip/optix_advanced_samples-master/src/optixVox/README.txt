
The optixVox sample for an older version of OptiX has been removed.  Please refer to the newer VOX sample in the OWL
repository: https://github.com/owl-project/owl
