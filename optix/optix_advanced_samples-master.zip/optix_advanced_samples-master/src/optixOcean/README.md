
optixOcean
==========

![Procedural ocean](./optixOcean.png)

Demonstrates interop between OptiX and CUDA.  Based on the "oceanFFT" CUDA sample.

