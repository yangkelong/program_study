
Credits:


Teapot:

Benedikt Bitterli
https://benedikt-bitterli.me/resources
Public domain license


VOX file(s):

Mike Judge
https://github.com/mikelovesrobots/mmmm
Creative Commons Attribution 4.0 International license (https://creativecommons.org/licenses/by/4.0)

