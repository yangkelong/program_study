
optixProgressivePhotonMap
=========================

![Scene with caustics](./optixProgressivePhotonMap.png)

A sample that uses progressive photon mapping (Hachisuka, Siggraph Asia 08) to render caustics with multiple passes.


