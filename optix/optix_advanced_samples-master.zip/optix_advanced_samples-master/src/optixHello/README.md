
optixHello
==========

This sample is adapted from the regular OptiX SDK, and included here as a smoke test.
It displays a green rectangle if things are installed properly.

