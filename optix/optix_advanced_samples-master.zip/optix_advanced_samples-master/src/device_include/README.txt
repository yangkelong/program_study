This directory contains common headers for device or device/host functions.

Common host code lives in ../sutil.

Device .cu files should be placed directly in sample directories.

